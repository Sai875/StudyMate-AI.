# Build Log - StudyMate AI (FL-07)

Rule: write this honestly as you go. Record failures, fixes and cuts. Do not rewrite it afterwards to look clean.

| # | Date | What I tried | What broke / what I noticed | What I changed | Cut from spec (why) |
|---|------|--------------|-----------------------------|----------------|---------------------|
| 1 | | Created folder structure, README, AGENT-INSTRUCTIONS.md (scaffold prepared with AI help) | | | |
| 2 | | First run on a small PDF | | | |

## Final successful run
- Date:
- PDF used:
- Run time:
- Files produced:
- Hand-edited mid-run? (must be No):

## Deviations from the FL-06 spec
-
