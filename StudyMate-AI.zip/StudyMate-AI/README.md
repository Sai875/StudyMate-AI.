# StudyMate AI

A PDF-to-exam-notes agent built on Claude Cowork (Windows 11) for FL-07.

## What it does
Reads study PDFs from input/ and writes exam-ready notes to output/<pdf-name>/:
01 document map, 02 five-mark answers, 03 ten-mark answers, 04 important questions,
05 study summary, 06 quality report. Every answer carries source page references.

## How to run
1. Put one PDF in input/.
2. Open Claude Cowork and connect this StudyMate-AI folder.
3. Tell Claude: "Follow instructions/AGENT-INSTRUCTIONS.md and process the PDF in input/."
4. Wait for the final message. Results are in output/.

## Live connection
The agent reads and writes real files in the connected local folder (file access in Cowork).

## Known limitations
(Fill in after your real runs - see build-log.md.)
