# FL-07 Submission Checklist
- [ ] Working agent: instructions/AGENT-INSTRUCTIONS.md
- [ ] Live connection: connected local folder (screenshot of Cowork with folder connected)
- [ ] Build log: build-log.md (real iteration)
- [ ] Raw run capture: one unedited ~2 min screen recording, request to result
- [ ] Spec deviations documented in build-log.md
