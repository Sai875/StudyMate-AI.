# Test Checklist

Run with one short, text-based PDF first (5-15 pages), then a longer or scanned one.

## Run info
- PDF:
- Date:
- Pass / Fail:

## Checks
- [ ] Agent read the PDF from input/ and the original file is unchanged
- [ ] 01-document-map.md lists subject, chapters, page ranges
- [ ] 02-five-mark-answers.md exists, each answer has intro, definition, ~5 points, conclusion
- [ ] 03-ten-mark-answers.md exists, has headings, characteristics, example, conclusion
- [ ] 04-important-questions.md exists, chapter-wise, short + long + definitions
- [ ] 05-study-summary.md exists, has glossary and revision points
- [ ] 06-quality-report.md exists and lists corrections made
- [ ] Spot-check 5 facts against the PDF: all match
- [ ] Spot-check 5 page references: all correct
- [ ] Anything unreadable is flagged, not guessed
- [ ] No mid-run manual editing was needed
- [ ] No existing file was overwritten or deleted

## Problems found
-
