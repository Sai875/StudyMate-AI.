# Submission folder

Save genuine, unedited FL-07 screen recording and required submission evidence here. Do not upload placeholders or fabricated evidence.
