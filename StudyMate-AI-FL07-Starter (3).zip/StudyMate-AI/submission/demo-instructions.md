# FL-07 Demo and Submission Instructions

## Before recording
1. Put a course PDF you are allowed to use in `input/` (a short, text-based 5–15 page PDF is a good first test).
2. Open Claude Desktop → Cowork and connect the StudyMate-AI project folder.
3. Run the first-run prompt in the repository README.
4. Wait for the actual task to finish. Review generated files and complete the test checklist.
5. Fix issues where possible, rerun if needed, and record each attempt honestly in `build-log.md`.

## Approximately 2-minute raw screen recording
Use Windows Game Bar (Win+G, then start recording) or another screen recorder:
- 0:00–0:20 — show project folder and source PDF in `input/`.
- 0:20–0:40 — show Cowork connected to the project folder and submitted task prompt.
- 0:40–1:20 — show the real processing run/progress.
- 1:20–1:45 — show the quality-check report and generated Markdown outputs.
- 1:45–2:00 — open the output folder and show saved files.

Keep the original recording unedited. Check that it plays and text is readable. Do not present a partial run as a completed run.

## Submission checklist
- [ ] Working Cowork workflow demonstrated on a real PDF.
- [ ] Connected folder/tool access shown.
- [ ] Build log includes real issues, fixes and test results.
- [ ] Test checklist completed honestly.
- [ ] Raw, unedited screen recording saved.
- [ ] No private data, API keys or copyrighted material shared publicly without permission.

Repository documentation is not proof of execution. The student must personally perform and record the Cowork run.
