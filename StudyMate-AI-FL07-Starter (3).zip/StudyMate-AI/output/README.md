# Output folder

Claude Cowork should save generated Markdown deliverables here after a real run. Do not add empty or fabricated result files.
