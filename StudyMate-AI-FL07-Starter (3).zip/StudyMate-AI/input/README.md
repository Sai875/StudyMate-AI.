# Input folder

Place one course PDF here for the first run. Use a PDF you are allowed to process. Do not commit private or copyrighted course material to this public repository.
