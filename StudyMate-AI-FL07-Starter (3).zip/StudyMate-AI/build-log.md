# StudyMate AI — Build Log

> Append dated entries describing work that actually happened. Do not backdate, invent errors/fixes, or mark planned work as completed. Keep repository documentation work separate from student-run Cowork results.

## Project
- Project: StudyMate AI — PDF-to-Exam Notes Agent
- Platform: Claude Cowork
- Environment: Windows 11
- Initial core scope: one PDF → summary + 5-mark answers + 10-mark answers → source check → saved files.

## Starter documentation
- Status: documentation/template package prepared.
- Cowork execution: NOT RUN.
- PDF processing: NOT RUN.
- Output verification: NOT RUN.
- Screen recording: NOT CREATED.
- Known limitation: a real input PDF and a real Cowork run are required to validate end-to-end behaviour.

## Append one entry for every actual Cowork run
### Run template
- Date/time:
- Input PDF:
- Platform/session:
- Actions actually performed:
- Output files created:
- Files reopened and verified:
- Tests performed and results:
- Errors or unexpected behaviour:
- Fixes applied:
- Remaining limitations:
- Overall result: NOT RUN / PASS / PARTIAL / BLOCKED
