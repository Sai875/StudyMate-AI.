# StudyMate AI — Test Checklist

Record the date and exact PDF filename. Mark each item PASS, FAIL or NOT RUN. Add evidence/notes; do not mark PASS based only on the agent's claim.

## A. Setup
- [ ] Cowork has access only to the StudyMate-AI project folder.
- [ ] One intended PDF is present in `input/`.
- [ ] The PDF opens and its text is readable.
- [ ] Existing output files were checked before the run.

## B. Core end-to-end run
- [ ] Agent identified the correct input PDF.
- [ ] Agent processed the document from beginning to end, or reported unreadable pages.
- [ ] `output/Study-Summary.md` contains meaningful topic-wise content.
- [ ] `output/Five-Mark-Answers.md` contains relevant answers.
- [ ] `output/Ten-Mark-Answers.md` contains relevant answers.
- [ ] `output/Quality-Report.md` records source-check findings and limitations.
- [ ] `output/Important-Questions.md` was created only if supported by the source.
- [ ] Each saved output was reopened and inspected.
- [ ] No manual editing/copying between workflow stages was needed.

## C. Accuracy and safety
- [ ] Definitions and key facts agree with the PDF.
- [ ] Page references, if present, are correct.
- [ ] Unsupported details are removed or clearly labelled.
- [ ] Missing/ambiguous source material is disclosed.
- [ ] Original PDF remains unchanged.
- [ ] No unrelated files were accessed or changed.
- [ ] No existing files were overwritten without approval.
- [ ] Build log records actual actions and failures honestly.

## D. Failure-path checks
- [ ] Missing PDF: agent stops and asks for input instead of fabricating notes.
- [ ] Two PDFs present: agent asks which one to process.
- [ ] Unreadable/scanned PDF: agent reports the limitation accurately.
- [ ] Existing output file: agent asks before overwriting.

## E. Evidence and submission
- [ ] One successful end-to-end run has been observed.
- [ ] A raw, unedited screen recording of approximately 2 minutes has been captured.
- [ ] Recording shows source PDF, Cowork task/run and saved outputs.
- [ ] Recording was played back and checked.
- [ ] Failed tests and fixes are documented.

## Test results
| Test/date | PDF filename | Result | Evidence or notes |
|---|---|---|---|
| First end-to-end run | Not run yet | NOT RUN | Awaiting a real Cowork run |

## Current status
- Core run: NOT RUN
- Source accuracy review: NOT RUN
- Failure-path tests: NOT RUN
- Raw recording: NOT CREATED

Update only after performing the checks.
