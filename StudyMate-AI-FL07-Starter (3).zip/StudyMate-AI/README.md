# StudyMate AI — PDF-to-Exam Notes Agent

A beginner-friendly, bounded agent workflow for turning one course PDF into source-grounded exam-preparation notes using **Claude Cowork**.

## What it does
1. Reads one PDF placed in `input/`.
2. Identifies the subject, chapters, headings, key terms, definitions, explanations and examples.
3. Creates a study summary, 5-mark answers and 10-mark answers.
4. Checks generated content against the source PDF, makes one correction pass and records limitations.
5. Saves Markdown deliverables in `output/` and records actual run details in `build-log.md`.

**First milestone:** one PDF → summary + 5-mark answers + 10-mark answers → source check → saved files. Additional features must not block this core workflow.

## Structure
```text
StudyMate-AI/
├── README.md
├── instructions/AGENT-INSTRUCTIONS.md
├── input/                 # Put your own course PDF here
├── output/                # Cowork-generated files appear here
├── tests/test-checklist.md
├── submission/demo-instructions.md
└── build-log.md
```

## Windows 11 setup
1. Put one readable, text-based course PDF (about 5–15 pages for the first test) in `input/`.
2. Open Claude Desktop, choose Cowork, and explicitly connect/grant access to this project folder only.
3. Review permission requests before approving them.
4. Give Cowork the first-run prompt below.
5. Inspect the outputs and complete `tests/test-checklist.md`. Record only real events in `build-log.md`.

## First-run prompt
```text
Read instructions/AGENT-INSTRUCTIONS.md and follow it.

Use the PDF in input/ as the source. Process it from beginning to end.
Create Study-Summary.md, Five-Mark-Answers.md and Ten-Mark-Answers.md
in output/. Also create Important-Questions.md and Quality-Report.md if
the source supports them. Check every generated answer against the PDF,
make one correction pass, and report page references where available.

Do not invent facts, page numbers, chapters or test results. If the PDF is
missing, unreadable or ambiguous, stop and tell me exactly what is missing.
Do not edit or delete the source PDF. Do not overwrite existing output
files without asking first. Verify each saved file after writing it.
Update build-log.md with the actual date, source filename, work performed,
files created, checks performed, failures and fixes. Mark anything not
run as NOT RUN. Finish with a concise execution report.
```

## Expected output files
- `output/Study-Summary.md`
- `output/Five-Mark-Answers.md`
- `output/Ten-Mark-Answers.md`
- `output/Important-Questions.md` (only when supported by the source)
- `output/Quality-Report.md`

The agent must not create fake output just to make a checklist look complete.

## Safety and quality
- Treat the PDF as the source of truth.
- Include page references only when verified.
- Clearly mark missing, unreadable or conflicting source material.
- Never claim a test passed unless it was actually checked.
- Ask before overwriting, deleting or moving user files.
- Keep the original PDF unchanged.
- Do not put passwords, API keys, private student records or other secrets in this public repository.
- Do not commit copyrighted course PDFs or generated notes unless you have permission to share them.

## FL-07 evidence
A successful Cowork run, actual test results and an unedited screen recording are separate evidence that the student must produce. See `submission/demo-instructions.md`. Do not claim those items exist until they have actually been created and reviewed.
